function validiranje() {

    var mojDiv=document.getElementById("mojDivPoruke");
    var validacija = new Validacija(mojDiv);
    validacija.naziv(document.getElementById("pas"));
    
    
    
    }