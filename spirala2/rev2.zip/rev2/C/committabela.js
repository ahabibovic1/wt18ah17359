var CommitTabela=(function(){
  
    
    var konstruktor=function(divElement, brojZadataka){
        
        var i;

        tbl  = document.createElement('table');
       tbl.style.width  = '900px';
        tbl.style.border = '1px solid black';
                tbl.id="tabela";

                var j;

                var tr = tbl.insertRow();             

                var th = tr.insertCell();
                th.style.border = '1px solid black';
                th.appendChild(document.createTextNode('Zadaci '));

                th = tr.insertCell();
                th.style.border = '1px solid black';

                th.appendChild(document.createTextNode('Commiti'));

            for(var i = 0; i < brojZadataka; i++){
                var tr = tbl.insertRow();             
                        var td = tr.insertCell();
                        td.style.border = '1px solid black';

                        j = i+1;
                        td.appendChild(document.createTextNode('Zadatak ' + j));
                        var tx = tr.insertCell();  
                        tx.style.border = '1px solid black';
                        tx.appendChild(document.createTextNode('') );                     
                  }
            

                  divElement.appendChild(tbl);
        

    return{
    dodajCommit:function(rbZadatka,url){
        rbZadatka++;

        var x = document.getElementById("tabela").rows[rbZadatka].cells;
        var br = document.getElementById("tabela").rows.length;
        var row = document.getElementById("tabela").rows[rbZadatka]; 
        var i;
        var j;
        var row2;
        var nesto;
        var col;
        var broj = row.cells.length;
        var a = document.createElement("a");
        var k = false;
        var petlja = broj-1;


        for( i = broj-1; i > 0; i--) {

       if (x[i].innerHTML== '') {
        a.setAttribute('href', url);
        a.innerHTML = i;
        x[i].appendChild(a);
        x[i].style.border = '1px solid black';
        
    for( j = 0; j < br; j++) {
        if(document.getElementById("tabela").rows[j].cells.length > broj && rbZadatka != j) {
      k = true;
          }
        }


        if(k == true ) {  
          nesto = row.insertCell(-1);
          nesto.style.border = '1px solid black';
          nesto.colSpan = x[i].colSpan - 1;
          x[i].colSpan = 1;

          
               }

           break;
       
    }
   
    if(i == petlja) {
        nesto = row.insertCell(-1);
        a.setAttribute('href', url);
        a.innerHTML = row.cells.length-1;
        nesto.style.border = '1px solid black';
        nesto.appendChild(a);
        
     


        for( i = 0; i < br; i++) {
            if(document.getElementById("tabela").rows[i].cells.length <= broj && rbZadatka != i) {
          k = true;
              }
            }

              if(k == true ) {

                row2 = document.getElementById("tabela").rows[0];
                nesto = row2.cells[1];
                col = nesto.colSpan;
                col++;
                nesto.colSpan = col;
    
        for( j = 1; j < br; j++) {
            row2 = document.getElementById("tabela").rows[j];

            if (j != rbZadatka) {
             
              if (row2.cells[row2.cells.length-1].innerHTML == '') {
            nesto = row2.cells[row2.cells.length-1];
             col = nesto.colSpan;
             nesto.colSpan = col+1;
               
            }
            else {     
              nesto = row2.insertCell(-1);
            nesto.style.border = '1px solid black';
            nesto.appendChild(document.createTextNode('') );

               
                }
              }
   
           }
        }
break;
    }


        }


    },
    editujCommit:function(rbZadatka,rbCommita,url){
        rbZadatka++;

        if(rbZadatka >= document.getElementById("tabela").rows.length || rbZadatka <= 0) {
            return -1;

        }
        if(rbCommita <= 0) {
            return -1;

        }
        var i;
        var w = document.getElementById("tabela").rows[rbZadatka].cells;
        var broj = document.getElementById("tabela").rows[rbZadatka].cells.length;
        for( i = 1; i < broj; i++) {

            if(w[i].textContent == String(rbCommita)) {
                w[i].innerHTML = '';
                var a = document.createElement("a");
                a.textContent = rbCommita;
                a.setAttribute('href', url);
                w[i].appendChild(a);
                break;
            }
            if(i == broj-1) {
                return -1;
            }  

        }
       


    },
    obrisiCommit:function(rbZadatka,rbCommita){
        rbZadatka++;

        if(rbZadatka >= document.getElementById("tabela").rows.length || rbZadatka <= 0) {
            return -1;

        }
        if(rbCommita <= 0) {
            return -1;

        }
        
        var y = document.getElementById("tabela").rows[rbZadatka];
        var i;
        var j = false;
        var col;
        var w = document.getElementById("tabela").rows[rbZadatka].cells;
        var k = document.getElementById("tabela").rows.length;
        for(i = 1; i < document.getElementById("tabela").rows[rbZadatka].cells.length; i++) {

            if(w[i].textContent == String(rbCommita)) {
                y.deleteCell(i);
                break;
            }
            if(i == document.getElementById("tabela").rows[rbZadatka].cells.length-1) {
                return -1;
            }
        }
        var br = document.getElementById("tabela").rows[rbZadatka].cells.length;
        var row;
        var n;


  for( i = 0; i < k; i++) {
      y = document.getElementById("tabela").rows[i].cells.length;

    if(y > br && i != rbZadatka && document.getElementById("tabela").rows[i].cells[y-1].innerHTML != '') {
  j = true;

      }
    }

     if( j == true ) {
        col = w[w.length-1].colSpan;
     if(w[w.length-1].innerHTML == '') {
        col++;
       w[w.length-1].colSpan = col;
     }
     else {

        y = document.getElementById("tabela").rows[rbZadatka]; 
        w[w.length-1].colSpan = 1;
        k = y.insertCell(-1);
        k.colSpan = col-1;
        k.style.border = '1px solid black';
     }
  }

    else {


        for (i = 0; i < k; i++) {
            row=document.getElementById("tabela").rows[i];
            if(i != rbZadatka) {
              n = row.cells[row.cells.length-1];
              col = n.colSpan;
              if(col == 1) {
                  row.deleteCell(row.cells.length-1);
              }
              else {
                  n.colSpan = col-1;
              }
              }
         }
    }
    
    }
    }

    }
    return konstruktor;
    }());

    
    var mojDiv=document.getElementById("zatabelu");
    var tabela= new CommitTabela(mojDiv,4);
    tabela.dodajCommit(0,"www.etf.ba");
    tabela.dodajCommit(1,"www.etf.ba");
    tabela.dodajCommit(2,"www.etf.ba");
    tabela.dodajCommit(3,"www.etf.ba");
    tabela.dodajCommit(0,"www.etf.ba");
    tabela.dodajCommit(0,"www.etf.ba");
    tabela.dodajCommit(1,"www.etf.ba");

    tabela.obrisiCommit(1,1);

























   












 

  

       


    