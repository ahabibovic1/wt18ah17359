function validirajAddZadatk() {
    var inputVjezba = document.getElementsByName("naziv")[0];
    var mojDiv = document.getElementById("mojDivPoruke");
    var validacija = new Validacija(mojDiv);
    validacija.naziv(inputVjezba);
}