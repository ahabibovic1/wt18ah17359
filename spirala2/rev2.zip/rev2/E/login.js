function validirajLogin() {
    console.log("USAOOO");
    var inputUsername = document.getElementsByName("username")[0];
    var inputPassword = document.getElementsByName("password")[0];
    var mojDiv = document.getElementById("mojDivPoruke");
    var validacija = new Validacija(mojDiv);
    validacija.naziv(inputUsername);
    validacija.password(inputPassword);
}