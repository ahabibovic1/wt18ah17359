function validirajAddStudent() {
    var inputIme = document.getElementsByName("ime")[0];
    var inputIndex = document.getElementsByName("index")[0];
    var mojDiv = document.getElementById("mojDivPoruke");
    var validacija = new Validacija(mojDiv);
    validacija.ime(inputIme);
    validacija.index(inputIndex);
}