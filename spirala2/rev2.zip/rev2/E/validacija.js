var Validacija = (function () {

    var konstruktor = function (divElementPoruke) {
        var poruka = "";
        return {
            ime: function (inputElement) {
                var regex = /^([A-Z]'{0,1}([a-z]'{0,1})+[ -]){1,4}$/;
                var tmp = inputElement.value;
                console.log(tmp[tmp.length - 1]);
                if(tmp[tmp.length - 1] != " ") tmp += " ";
                if (!regex.test(tmp)) {
                    inputElement.style.backgroundColor = "orangered";
                    poruka = napraviPorukuGreska(divElementPoruke, "ime");
                    divElementPoruke.innerHTML = poruka;
                } else {
                    inputElement.style.backgroundColor = "white";
                    poruka = napraviPorukuTacno(divElementPoruke, "ime");
                    divElementPoruke.innerHTML = poruka;
                }
            },
            godina: function (inputElement) {
                var regex = /^20\d\d\/20\d\d$/;
                var g = inputElement.value;
                var num1;
                var num2;
                if(g.length != 9) {
                    num1 = 0;
                    num2 = 0;
                }  
                var godine = g.split("");
                num1 = (godine[2] - '0') * 10 + (godine[3] - '0');
                num2 = (godine[7] - '0') * 10 + (godine[8] - '0');
                if (!(regex.test(inputElement.value) && num1 + 1 == num2)) {
                    inputElement.style.backgroundColor = "orangered";
                    poruka = napraviPorukuGreska(divElementPoruke, "godina");
                    divElementPoruke.innerHTML = poruka;
                } else {
                    inputElement.style.backgroundColor = "white";
                    poruka = napraviPorukuTacno(divElementPoruke, "godina");
                    divElementPoruke.innerHTML = poruka;
                }
            },
            repozitorij: function (inputElement, regex) {
                if (!regex.test(inputElement.value)) {
                    inputElement.style.backgroundColor = "orangered";
                    poruka = napraviPorukuGreska(divElementPoruke, "repozitorij");
                    divElementPoruke.innerHTML = poruka;
                } else {
                    inputElement.style.backgroundColor = "white";
                    poruka = napraviPorukuTacno(divElementPoruke, "repozitorij");
                    divElementPoruke.innerHTML = poruka;
                }
            },
            index: function (inputElement) {
                var regex = /^(14|15|16|17|18|19|20)\d{3}$/;
                if (!regex.test(inputElement.value)) {
                    inputElement.style.backgroundColor = "orangered";
                    poruka = napraviPorukuGreska(divElementPoruke, "index");
                    divElementPoruke.innerHTML = poruka;
                } else {
                    inputElement.style.backgroundColor = "white";
                    poruka = napraviPorukuTacno(divElementPoruke, "index");
                    divElementPoruke.innerHTML = poruka;
                }
            },
            naziv: function (inputElement) {
                var regex = /(?=.{3,}$)^([A-Z]|[a-z])([A-Z]|[a-z]|\\|\/|\-|\"|\'|\!|\?|\:|\;|\,|\d)*([a-z]|\d)$/;
                console.log(regex);
                if (!regex.test(inputElement.value)) {
                    inputElement.style.backgroundColor = "orangered";
                    poruka = napraviPorukuGreska(divElementPoruke, "naziv");
                    divElementPoruke.innerHTML = poruka;
                } else {
                    inputElement.style.backgroundColor = "white";
                    poruka = napraviPorukuTacno(divElementPoruke, "naziv");
                    divElementPoruke.innerHTML = poruka;
                }
            },
            password: function (inputElement) {
                var regex = /^(?=.{8,}$)(?=(.*[A-Z]){2})(?=(.*[a-z]){2})(?=(.*[0-9]){2})(?=\S+$).*$/;
                if (!regex.test(inputElement.value)) {
                    inputElement.style.backgroundColor = "orangered";
                    poruka = napraviPorukuGreska(divElementPoruke, "password");
                    divElementPoruke.innerHTML = poruka;
                } else {
                    inputElement.style.backgroundColor = "white";
                    poruka = napraviPorukuTacno(divElementPoruke, "password");
                    divElementPoruke.innerHTML = poruka;
                }
            },
            url: function (inputElement) {
                var regex = new RegExp("^((http|https|ftp):\/\/\([\\d\\w]*([.]?[\\d\\w]+)+)+(\/[\\d\\w]+)*\\?([\\d\\w]+\=[\\d\\w]+\&)*[\\d\\w]+\=[\\d\\w]+$)$|^((http|https|ftp):\/\/\([\\d\\w]*([.]?[\\d\\w]+)+)+(\/[\\d\\w]+)*)");
                if (!regex.test(inputElement.value)) {
                    inputElement.style.backgroundColor = "orangered";
                    poruka = napraviPorukuGreska(divElementPoruke, "url");
                    divElementPoruke.innerHTML = poruka;
                } else {
                    inputElement.style.backgroundColor = "white";
                    poruka = napraviPorukuTacno(divElementPoruke, "url");
                    divElementPoruke.innerHTML = poruka;
                } poruka = poruka.replace("url,", '');
            }
        }
    }
    return konstruktor;
}());

function napraviPorukuGreska(div, porukica) {
    var poruka = div.innerHTML;
    if(poruka == "") poruka = "Sljedeća polja nisu validna: ";
    if(poruka.includes(porukica)) return poruka;
    if (poruka.includes("!"))
        poruka = poruka.replace('!', ", " + porukica + "!");
    else poruka += porukica + "!";
    return poruka;
}

function napraviPorukuTacno(div, porukica) {
    var poruka = div.innerHTML;
    console.log(poruka);
    if (poruka.includes(", " + porukica + "!"))
        poruka = poruka.replace(", " + porukica + "!", '!');
    else if (poruka.includes(", " + porukica + ","))
        poruka = poruka.replace(", " + porukica + ",", ",");
    else if (poruka.includes(porukica + ","))
        poruka = poruka.replace(porukica + ",", '');
    else if (poruka.includes(porukica + "!"))
        poruka = poruka.replace(porukica + "!", '');
    if(!poruka.includes("!")) poruka = "";
    return poruka;
}