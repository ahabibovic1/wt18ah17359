function validirajAddVjezba() {
    var inputVjezba = document.getElementsByName("vjezba")[0];
    var mojDiv = document.getElementById("mojDivPoruke");
    var validacija = new Validacija(mojDiv);
    validacija.naziv(inputVjezba);
}