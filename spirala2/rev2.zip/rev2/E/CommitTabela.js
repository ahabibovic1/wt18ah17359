var CommitTabela = (function () {

    var konstruktor = function (divElement, brojZadataka) {
        brojZadataka = parseInt(brojZadataka.value);
        var tabela = document.createElement('table');
        tabela.id = "commiti";
        var row = document.createElement('tr');
        var col1 = document.createElement('th');
        var col2 = document.createElement('th');
        col1.innerHTML = "Novi zadatak"
        col2.innerHTML = "Commiti";
        col1.colSpan = 1;
        col2.colSpan = 1;
        row.appendChild(col1);
        row.appendChild(col2);
        tabela.appendChild(row);
        for (var i = 0; i < brojZadataka; i++) {
            row = document.createElement('tr');
            row.innerHTML = "Zadatak" + (i + 1);
            col = document.createElement('td');
            col.colSpan = 1;
            row.appendChild(col);
            tabela.appendChild(row);
        }
        divElement.appendChild(tabela);

        return {
            dodajCommit: function (rbZadatka, url) {
                var Url = url.value;
                var zadatak = parseInt(rbZadatka.value);
                zadatak = zadatak + 1;

                if (zadatak > brojZadataka) return -1;

                var j = tabela.rows[zadatak].cells.length;
                var colIspred = tabela.rows[zadatak].cells[j - 1];
                var maksimum = maxBrKolona(tabela, brojZadataka);

                if (!colIspred.innerHTML && maksimum == j) { //prazna zadnja i max
                    var br;
                    if (j == 1) br = 0;
                    else br = tabela.rows[zadatak].getElementsByTagName('a')[j - 2].text;
                    br++;
                    console.log(br);
                    colIspred.innerHTML = "<a href=" + Url + ">" + br + "</a>";
                } else if (!colIspred.innerHTML && maksimum != j) { //prazna zadnja a nije max
                    var br;
                    if (j == 1) br = 0;
                    else br = tabela.rows[zadatak].getElementsByTagName('a')[j - 2].text;
                    br++;
                    colIspred.innerHTML = "<a href=" + Url + ">" + br + "</a>";
                    colIspred.colSpan = 1;
                    var y = tabela.rows[zadatak].insertCell();
                    y.colSpan = maksimum - tabela.rows[zadatak].cells.length + 1;
                } else { //nije prazna zadnja
                    var col = tabela.rows[zadatak].insertCell(j);
                    var br;
                    br = tabela.rows[zadatak].getElementsByTagName('a')[j - 1].text;
                    br++;
                    col.innerHTML = "<a href=" + Url + ">" + br + "</a>";
                    tabela.rows[0].cells[1].colSpan += 1;
                    var brKolona = tabela.rows[zadatak].cells.length;
                    var max = maxBrKolona(tabela, brojZadataka);
                    if (brKolona == max || colIspred.cellIndex == j - 1) { //max
                        for (var i = 1; i <= brojZadataka; i++) {
                            if (i != zadatak) {
                                var j = tabela.rows[i].cells.length;
                                if (!(tabela.rows[i].cells[j - 1].innerHTML))
                                    tabela.rows[i].cells[j - 1].colSpan += 1;
                                else
                                    var col = tabela.rows[i].insertCell(j);
                            }
                        }
                    }
                }
            },
            editujCommit: function (rbZadatka, rbCommita, url) {
                var zadatak = parseInt(rbZadatka.value);
                var kolona = parseInt(rbCommita.value);
                var Url = url.value;
                if (zadatak + 1 > brojZadataka || kolona < 0 || kolona >= tabela.rows[zadatak + 1].cells.length) return -1;
                
                var j = tabela.rows[zadatak + 1].cells.length;
                var br;
                if (j == 1) br = 0;
                else br = tabela.rows[zadatak + 1].getElementsByTagName('a')[j - 2].text;
                br++;
                tabela.rows[zadatak + 1].cells[kolona].innerHTML = "<a href=" + Url + ">" + br + "</a>";
            },
            obrisiCommit: function (rbZadatka, rbCommita) {
                var zadatak = parseInt(rbZadatka.value);
                var kolona = parseInt(rbCommita.value);
                if (zadatak + 1 > brojZadataka || kolona < 0 || kolona >= tabela.rows[zadatak + 1].cells.length)
                    return -1;

                var red = tabela.rows[zadatak + 1];
                var brKolona = red.cells.length;
                var max = maxBrKolona(tabela, brojZadataka + 1);
                if (!red.cells[brKolona - 1].innerHTML) brKolona--;
                if (brKolona == max) {

                    var max2 = 0;
                    for (var i = 1; i <= brojZadataka; i++) {
                        if (i != zadatak + 1) {
                            var tmp = tabela.rows[i].cells.length;
                            if (!tabela.rows[i].cells[tmp - 1].innerHTML) tmp--;
                            if (tmp > max2) max2 = tmp;
                        }
                    }
                    if (max == max2) {
                        if (kolona == brKolona - 1)
                            red.cells[kolona].innerHTML = "";
                        else {
                            red.deleteCell(kolona);
                            var tmp = red.insertCell(brKolona - 1);
                            tmp.colSpan = 1;
                        }

                    } else {
                        red.deleteCell(kolona);
                        for (var i = 1; i <= brojZadataka; i++) {
                            if (i != zadatak + 1) {
                                if (tabela.rows[i].cells[tabela.rows[i].cells.length - 1].colSpan == 1)
                                    tabela.rows[i].deleteCell(tabela.rows[i].cells.length - 1);
                                else
                                    tabela.rows[i].cells[tabela.rows[i].cells.length - 1].colSpan -= 1;
                            }
                        }
                    }
                } else {

                    if (brKolona == kolona)
                        red.cells[kolona].innerHTML = "";
                    else {
                        red.deleteCell(kolona);
                        brKolona = red.cells.length;
                        red.cells[brKolona - 1].colSpan += 1;
                    }
                }
            }
        }
    }
    return konstruktor;
}());

function maxBrKolona(tabela, brRedova) {
    var max = 0;
    for (var i = 1; i < brRedova; i++) {
        if (tabela.rows[i].cells.length > max)
            max = tabela.rows[i].cells.length;
    }
    return max;
}