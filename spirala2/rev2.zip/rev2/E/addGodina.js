function validirajAddGodina() {
    var inputNaziv = document.getElementsByName("naziv")[0];
    var repozitorijVjezba = document.getElementsByName("rvjezbe")[0];
    var repozitorijSpirala = document.getElementsByName("rspiral")[0];

    var mojDiv = document.getElementById("mojDivPoruke");
    var validacija = new Validacija(mojDiv);
    validacija.godina(inputNaziv);
    var regex = new RegExp("repozitorij");
    validacija.repozitorij(repozitorijVjezba, regex);
    validacija.repozitorij(repozitorijSpirala, regex);
}