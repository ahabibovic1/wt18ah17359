var tabela;

function napraviTabelu() {
    var divElement = document.getElementById("tableDiv");
    var brojZadataka = document.getElementById("brRedova");
    tabela = new CommitTabela(divElement, brojZadataka);
}

function dodaj() {
    var brReda = document.getElementById("rbZadatka");
    var url = document.getElementById("url");
    
    var div = document.getElementById("mojDivPoruke");
    var validacija = new Validacija(div);
    validacija.url(url);

    if (url.style.backgroundColor != "orangered")
        tabela.dodajCommit(brReda, url);
}

function edit() {
    var brReda = document.getElementById("rbZadatka1");
    var brKolone = document.getElementById("rbCommita");
    var url = document.getElementById("url1");

    var div = document.getElementById("mojDivPoruke");
    var validacija = new Validacija(div);
    validacija.url(url);

    if (url.style.backgroundColor != "orangered")
        tabela.editujCommit(brReda, brKolone, url);
}

function obrisi() {
    var brReda = document.getElementById("rbZadatka2");
    var brKolone = document.getElementById("rbCommita1");
    tabela.obrisiCommit(brReda, brKolone);
}