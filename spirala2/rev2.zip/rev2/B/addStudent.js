var v = Validacija(document.getElementById('zagreske'));
var x ;

var AddStudent = function () {
    x = v(document.getElementById('zagreske'));
    if (x.ime(document.getElementById('ime').value)) {
        document.getElementById('ime').style.backgroundColor = "white";
	} else {
        document.getElementById('ime').style.backgroundColor = "orangered";
    }

    if (x.index(document.getElementById('index').value)) {
        document.getElementById('index').style.backgroundColor = "white";
	} else {
        document.getElementById('index').style.backgroundColor = "orangered";
    }

    return false;
}