

var Validacija = (function () {
	
	var konstruktor = function (zaPoruku) {
		var greskice = [];
		return {
            ime: function (ImeiPrezime) {
                var regexImeiPrezime = /^(([A-Z\�\�\�\�\�]{1}(\'?[a-z\�\�\�\�\�]+\'?[a-z\�\�\�\�\�]*)+)([ \-]{1}(([A-Z\�\�\�\�\�]{1})(\'?[a-z\�\�\�\�\�]+\'?[a-z\�\�\�\�\�]*)+)){0,3})$/gm;
                if (ImeiPrezime.match(regexImeiPrezime) == null) {
                    greskice.push("1");
                    //ispisivanje gresaka
                    if (greskice.length == 0) {
                        zaPoruku.style.visibility = "hidden";
                    }
                    if (greskice.length == 1) {
                        zaPoruku.style.visibility = "visible";
                    }
                    var i, text = "Sljedeca polja nisu validna: ";
                    for (i = 0; i < greskice.length; i++) {

                        if (greskice[i] == "1") {
                            text += "ime";
                        }
                        else if (greskice[i] == "2") {
                            text += "godina";
                        }
                        else if (greskice[i] == "3") {
                            text += "repozitorij";
                        }
                        else if (greskice[i] == "4") {
                            text += "index";
                        }
                        else if (greskice[i] == "5") {
                            text += "naziv";
                        }
                        else if (greskice[i] == "6") {
                            text += "password";
                        }
                        else if (greskice[i] == "7") {
                            text += "url";
                        }


                        if (i != greskice.length - 1) {
                            text += ", ";
                        }
                        else {
                            text += "!";
                        }
                    }
                    zaPoruku.innerHTML = text;

                    return false;
                }
                else {
                    var i = greskice.indexOf("1");
                    greskice.splice(i, 1);
                    //ispisavanje na div gresaka
                    if (greskice.length == 0) {
                        zaPoruku.style.visibility = "hidden";
                    }
                    if (greskice.length == 1) {
                        zaPoruku.style.visibility = "visible";
                    }
                    var i, text = "Sljedeca polja nisu validna: ";
                    for (i = 0; i < greskice.length; i++) {

                        if (greskice[i] == "1") {
                            text += "ime";
                        }
                        else if (greskice[i] == "2") {
                            text += "godina";
                        }
                        else if (greskice[i] == "3") {
                            text += "repozitorij";
                        }
                        else if (greskice[i] == "4") {
                            text += "index";
                        }
                        else if (greskice[i] == "5") {
                            text += "naziv";
                        }
                        else if (greskice[i] == "6") {
                            text += "password";
                        }
                        else if (greskice[i] == "7") {
                            text += "url";
                        }

                        if (i != greskice.length - 1) {
                            text += ", ";
                        }
                        else {
                            text += "!";
                        }
                    }
                    zaPoruku.innerHTML = text;

                    return true;
                }
            },
			godina: function (akGodina) {
                var regexAkGod = /(^20)(\d\d)\/(20)(\d\d)$/gm;
                if (akGodina.match(regexAkGod) != null) {
                    let m = regexAkGod.exec(akGodina);
                    var x, y;
                    x = parseInt(m[2]);
                    y = parseInt(m[4]);
                    //provjera da li se razlikuju za 1
                    if (y != x + 1) {
                        greskice.push("2");
                         //ispisavanje na div gresaka
                        if (greskice.length == 0) {
                            zaPoruku.style.visibility = "hidden";
                        }
                        if (greskice.length == 1) {
                            zaPoruku.style.visibility = "visible";
                        }
                        var i, text = "Sljedeca polja nisu validna: ";
                        for (i = 0; i < greskice.length; i++) {

                            if (greskice[i] == "1") {
                                text += "ime";
                            }
                            else if (greskice[i] == "2") {
                                text += "godina";
                            }
                            else if (greskice[i] == "3") {
                                text += "repozitorij";
                            }
                            else if (greskice[i] == "4") {
                                text += "index";
                            }
                            else if (greskice[i] == "5") {
                                text += "naziv";
                            }
                            else if (greskice[i] == "6") {
                                text += "password";
                            }
                            else if (greskice[i] == "7") {
                                text += "url";
                            }


                            if (i != greskice.length - 1) {
                                text += ", ";
                            }
                            else {
                                text += "!";
                            }
                        }
                        zaPoruku.innerHTML = text;
                        return false;
                    }
                    else { //dobar format i godine se razlikuju za 1
                        var i = greskice.indexOf("2");
                        greskice.splice(i, 1);
                         //ispisavanje na div gresaka
                        if (greskice.length == 0) {
                            zaPoruku.style.visibility = "hidden";
                        }
                        if (greskice.length == 1) {
                            zaPoruku.style.visibility = "visible";
                        }
                        var i, text = "Sljedeca polja nisu validna: ";
                        for (i = 0; i < greskice.length; i++) {

                            if (greskice[i] == "1") {
                                text += "ime";
                            }
                            else if (greskice[i] == "2") {
                                text += "godina";
                            }
                            else if (greskice[i] == "3") {
                                text += "repozitorij";
                            }
                            else if (greskice[i] == "4") {
                                text += "index";
                            }
                            else if (greskice[i] == "5") {
                                text += "naziv";
                            }
                            else if (greskice[i] == "6") {
                                text += "password";
                            }
                            else if (greskice[i] == "7") {
                                text += "url";
                            }


                            if (i != greskice.length - 1) {
                                text += ", ";
                            }
                            else {
                                text += "!";
                            }
                        }
                        zaPoruku.innerHTML = text;
                        return true;
                    }
                }
                else {//nije dobar format
                    greskice.push("2");
                     //ispisavanje na div gresaka
                    if (greskice.length == 0) {
                        zaPoruku.style.visibility = "hidden";
                    }
                    if (greskice.length == 1) {
                        zaPoruku.style.visibility = "visible";
                    }
                    var i, text = "Sljedeca polja nisu validna: ";
                    for (i = 0; i < greskice.length; i++) {

                        if (greskice[i] == "1") {
                            text += "ime";
                        }
                        else if (greskice[i] == "2") {
                            text += "godina";
                        }
                        else if (greskice[i] == "3") {
                            text += "repozitorij";
                        }
                        else if (greskice[i] == "4") {
                            text += "index";
                        }
                        else if (greskice[i] == "5") {
                            text += "naziv";
                        }
                        else if (greskice[i] == "6") {
                            text += "password";
                        }
                        else if (greskice[i] == "7") {
                            text += "url";
                        }


                        if (i != greskice.length - 1) {
                            text += ", ";
                        }
                        else {
                            text += "!";
                        }
                    }
                    zaPoruku.innerHTML = text;
                    return false;
                }

            },
            repozitorij: function (repozitorij, regex) {
                if (repozitorij.match(regex) == null) {
                    greskice.push("3");
                    if (greskice.length == 0) {
                        zaPoruku.style.visibility = "hidden";
                    }
                    if (greskice.length == 1) {
                        zaPoruku.style.visibility = "visible";
                    }
                    var i, text = "Sljedeca polja nisu validna: ";
                    for (i = 0; i < greskice.length; i++) {

                        if (greskice[i] == "1") {
                            text += "ime";
                        }
                        else if (greskice[i] == "2") {
                            text += "godina";
                        }
                        else if (greskice[i] == "3") {
                            text += "repozitorij";
                        }
                        else if (greskice[i] == "4") {
                            text += "index";
                        }
                        else if (greskice[i] == "5") {
                            text += "naziv";
                        }
                        else if (greskice[i] == "6") {
                            text += "password";
                        }
                        else if (greskice[i] == "7") {
                            text += "url";
                        }


                        if (i != greskice.length - 1) {
                            text += ", ";
                        }
                        else {
                            text += "!";
                        }
                    }
                    zaPoruku.innerHTML = text;
                    return false;
                }
                else {
                    var i = greskice.indexOf("3");
                    greskice.splice(i, 1);
                    if (greskice.length == 0) {
                        zaPoruku.style.visibility = "hidden";
                    }
                    if (greskice.length == 1) {
                        zaPoruku.style.visibility = "visible";
                    }
                    var i, text = "Sljedeca polja nisu validna: ";
                    for (i = 0; i < greskice.length; i++) {

                        if (greskice[i] == "1") {
                            text += "ime";
                        }
                        else if (greskice[i] == "2") {
                            text += "godina";
                        }
                        else if (greskice[i] == "3") {
                            text += "repozitorij";
                        }
                        else if (greskice[i] == "4") {
                            text += "index";
                        }
                        else if (greskice[i] == "5") {
                            text += "naziv";
                        }
                        else if (greskice[i] == "6") {
                            text += "password";
                        }
                        else if (greskice[i] == "7") {
                            text += "url";
                        }


                        if (i != greskice.length - 1) {
                            text += ", ";
                        }
                        else {
                            text += "!";
                        }
                    }
                    zaPoruku.innerHTML = text;
                    return true;
                }
            },
            index: function (index) {
                var regexIndex = /^((1[4-9]{1})|(20))\d{3}$/gm;
                if (index.match(regexIndex) == null) {
                    greskice.push("4");
                    if (greskice.length == 0) {
                        zaPoruku.style.visibility = "hidden";
                    }
                    if (greskice.length == 1) {
                        zaPoruku.style.visibility = "visible";
                    }
                    var i, text = "Sljedeca polja nisu validna: ";
                    for (i = 0; i < greskice.length; i++) {

                        if (greskice[i] == "1") {
                            text += "ime";
                        }
                        else if (greskice[i] == "2") {
                            text += "godina";
                        }
                        else if (greskice[i] == "3") {
                            text += "repozitorij";
                        }
                        else if (greskice[i] == "4") {
                            text += "index";
                        }
                        else if (greskice[i] == "5") {
                            text += "naziv";
                        }
                        else if (greskice[i] == "6") {
                            text += "password";
                        }
                        else if (greskice[i] == "7") {
                            text += "url";
                        }


                        if (i != greskice.length - 1) {
                            text += ", ";
                        }
                        else {
                            text += "!";
                        }
                    }
                    zaPoruku.innerHTML = text;
                    return false;
                }
                else {
                    var i = greskice.indexOf("4");
                    greskice.splice(i, 1);
                    if (greskice.length == 0) {
                        zaPoruku.style.visibility = "hidden";
                    }
                    if (greskice.length == 1) {
                        zaPoruku.style.visibility = "visible";
                    }
                    var i, text = "Sljedeca polja nisu validna: ";
                    for (i = 0; i < greskice.length; i++) {

                        if (greskice[i] == "1") {
                            text += "ime";
                        }
                        else if (greskice[i] == "2") {
                            text += "godina";
                        }
                        else if (greskice[i] == "3") {
                            text += "repozitorij";
                        }
                        else if (greskice[i] == "4") {
                            text += "index";
                        }
                        else if (greskice[i] == "5") {
                            text += "naziv";
                        }
                        else if (greskice[i] == "6") {
                            text += "password";
                        }
                        else if (greskice[i] == "7") {
                            text += "url";
                        }


                        if (i != greskice.length - 1) {
                            text += ", ";
                        }
                        else {
                            text += "!";
                        }
                    }
                    zaPoruku.innerHTML = text;
                    return true;
                }
            },
			naziv: function (naziv) {
                var regexNaziv = /^([a-zA-Z]{1}[\w\\\/\-\"\'\!\?\:\;\,]+[a-z0-9]{1})$/gm;
                if (naziv.match(regexNaziv) == null) {
                    greskice.push("5");
                    if (greskice.length == 0) {
                        zaPoruku.style.visibility = "hidden";
                    }
                    if (greskice.length == 1) {
                        zaPoruku.style.visibility = "visible";
                    }
                    var i, text = "Sljedeca polja nisu validna: ";
                    for (i = 0; i < greskice.length; i++) {

                        if (greskice[i] == "1") {
                            text += "ime";
                        }
                        else if (greskice[i] == "2") {
                            text += "godina";
                        }
                        else if (greskice[i] == "3") {
                            text += "repozitorij";
                        }
                        else if (greskice[i] == "4") {
                            text += "index";
                        }
                        else if (greskice[i] == "5") {
                            text += "naziv";
                        }
                        else if (greskice[i] == "6") {
                            text += "password";
                        }
                        else if (greskice[i] == "7") {
                            text += "url";
                        }


                        if (i != greskice.length - 1) {
                            text += ", ";
                        }
                        else {
                            text += "!";
                        }
                    }
                    zaPoruku.innerHTML = text;
                    return false;
                }
                else {
                    var i = greskice.indexOf("5");
                    greskice.splice(i, 1);
                    if (greskice.length == 0) {
                        zaPoruku.style.visibility = "hidden";
                    }
                    if (greskice.length == 1) {
                        zaPoruku.style.visibility = "visible";
                    }
                    var i, text = "Sljedeca polja nisu validna: ";
                    for (i = 0; i < greskice.length; i++) {

                        if (greskice[i] == "1") {
                            text += "ime";
                        }
                        else if (greskice[i] == "2") {
                            text += "godina";
                        }
                        else if (greskice[i] == "3") {
                            text += "repozitorij";
                        }
                        else if (greskice[i] == "4") {
                            text += "index";
                        }
                        else if (greskice[i] == "5") {
                            text += "naziv";
                        }
                        else if (greskice[i] == "6") {
                            text += "password";
                        }
                        else if (greskice[i] == "7") {
                            text += "url";
                        }


                        if (i != greskice.length - 1) {
                            text += ", ";
                        }
                        else {
                            text += "!";
                        }
                    }
                    zaPoruku.innerHTML = text;
                    return true;
                }
            },
			password: function (pass) {
                var regexpas = /((?=\w*?[a-z])(?=\w*?[0-9])\w{8,})|((?=\w*?[A-Z])(?=\w*?[0-9])\w{8,})|((?=\w*?[A-Z])(?=\w*?[a-z])\w{8,})/gm;
                if (pass.match(regexpas) == null) {
                    greskice.push("6");
                    if (greskice.length == 0) {
                        zaPoruku.style.visibility = "hidden";
                    }
                    if (greskice.length == 1) {
                        zaPoruku.style.visibility = "visible";
                    }
                    var i, text = "Sljedeca polja nisu validna: ";
                    for (i = 0; i < greskice.length; i++) {

                        if (greskice[i] == "1") {
                            text += "ime";
                        }
                        else if (greskice[i] == "2") {
                            text += "godina";
                        }
                        else if (greskice[i] == "3") {
                            text += "repozitorij";
                        }
                        else if (greskice[i] == "4") {
                            text += "index";
                        }
                        else if (greskice[i] == "5") {
                            text += "naziv";
                        }
                        else if (greskice[i] == "6") {
                            text += "password";
                        }
                        else if (greskice[i] == "7") {
                            text += "url";
                        }


                        if (i != greskice.length - 1) {
                            text += ", ";
                        }
                        else {
                            text += "!";
                        }
                    }
                    zaPoruku.innerHTML = text;
                    return false;
                }
                else {
                    var i = greskice.indexOf("6");
                    greskice.splice(i, 1);
                    if (greskice.length == 0) {
                        zaPoruku.style.visibility = "hidden";
                    }
                    if (greskice.length == 1) {
                        zaPoruku.style.visibility = "visible";
                    }
                    var i, text = "Sljedeca polja nisu validna: ";
                    for (i = 0; i < greskice.length; i++) {

                        if (greskice[i] == "1") {
                            text += "ime";
                        }
                        else if (greskice[i] == "2") {
                            text += "godina";
                        }
                        else if (greskice[i] == "3") {
                            text += "repozitorij";
                        }
                        else if (greskice[i] == "4") {
                            text += "index";
                        }
                        else if (greskice[i] == "5") {
                            text += "naziv";
                        }
                        else if (greskice[i] == "6") {
                            text += "password";
                        }
                        else if (greskice[i] == "7") {
                            text += "url";
                        }


                        if (i != greskice.length - 1) {
                            text += ", ";
                        }
                        else {
                            text += "!";
                        }
                    }
                    zaPoruku.innerHTML = text;
                    return true;
                }
            },
            url: function (url) {//protokol       |                                    host                                                |     |                          putanja                  | |        parametrii
                var regexurl = /^((http|https|ftp|ssh)(\:\/\/)?((([a-z0-9]+[a-z0-9\-]*[a-z0-9]+)|[a-z0-9]+)(\.(([a-z0-9]+[a-z0-9\-]*[a-z0-9]+)|[a-z0-9]+))*)(\/)?(\/(([a-z0-9]+[a-z0-9\-]*[a-z0-9]+)|[a-z0-9]+))*(\?(([a-z0-9]+[a-z0-9\-]*[a-z0-9]+)|[a-z0-9]+)\=(([a-z0-9]+[a-z0-9\-]*[a-z0-9]+)|[a-z0-9]+))?(\&(([a-z0-9]+[a-z0-9\-]*[a-z0-9]+)|[a-z0-9]+)\=(([a-z0-9]+[a-z0-9\-]*[a-z0-9]+)|[a-z0-9]+))*)$/gm;
                if (url.match(regexurl) == null) {
                    greskice.push("7");
                    if (greskice.length == 0) {
                        zaPoruku.style.visibility = "hidden";
                    }
                    if (greskice.length == 1) {
                        zaPoruku.style.visibility = "visible";
                    }
                    var i, text = "Sljedeca polja nisu validna: ";
                    for (i = 0; i < greskice.length; i++) {

                        if (greskice[i] == "1") {
                            text += "ime";
                        }
                        else if (greskice[i] == "2") {
                            text += "godina";
                        }
                        else if (greskice[i] == "3") {
                            text += "repozitorij";
                        }
                        else if (greskice[i] == "4") {
                            text += "index";
                        }
                        else if (greskice[i] == "5") {
                            text += "naziv";
                        }
                        else if (greskice[i] == "6") {
                            text += "password";
                        }
                        else if (greskice[i] == "7") {
                            text += "url";
                        }


                        if (i != greskice.length - 1) {
                            text += ", ";
                        }
                        else {
                            text += "!";
                        }
                    }
                    zaPoruku.innerHTML = text;
                    return false;
                }
                else {
                    var i = greskice.indexOf("7");
                    greskice.splice(i, 1);
                    if (greskice.length == 0) {
                        zaPoruku.style.visibility = "hidden";
                    }
                    if (greskice.length == 1) {
                        zaPoruku.style.visibility = "visible";
                    }
                    var i, text = "Sljedeca polja nisu validna: ";
                    for (i = 0; i < greskice.length; i++) {

                        if (greskice[i] == "1") {
                            text += "ime";
                        }
                        else if (greskice[i] == "2") {
                            text += "godina";
                        }
                        else if (greskice[i] == "3") {
                            text += "repozitorij";
                        }
                        else if (greskice[i] == "4") {
                            text += "index";
                        }
                        else if (greskice[i] == "5") {
                            text += "naziv";
                        }
                        else if (greskice[i] == "6") {
                            text += "password";
                        }
                        else if (greskice[i] == "7") {
                            text += "url";
                        }


                        if (i != greskice.length - 1) {
                            text += ", ";
                        }
                        else {
                            text += "!";
                        }
                    }
                    zaPoruku.innerHTML = text;
                    return true;
                }
            }
		}
	}
	return konstruktor;
});