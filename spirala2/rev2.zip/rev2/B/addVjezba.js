var v = Validacija(document.getElementById('zagreske'));
var x;

var AddVjezba = function () {

    x = v(document.getElementById('zagreske'));
   
    if (x.naziv(document.getElementById('naziv').value)) {
        document.getElementById('naziv').style.backgroundColor = "white";
	} else {
        document.getElementById('naziv').style.backgroundColor = "orangered";
    }
    return false;
}