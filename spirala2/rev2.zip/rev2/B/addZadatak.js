var v = Validacija(document.getElementById('zagresku'));
var x;

var AddZadatak = function () {

    x = v(document.getElementById('zagresku'));
    if (x.naziv(document.getElementById('naziv').value)) {
        document.getElementById('naziv').style.backgroundColor = "white";
	} else {
        document.getElementById('naziv').style.backgroundColor = "orangered";
    }
    return false;
}