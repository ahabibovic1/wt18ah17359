var CommitTabela=(function(){


    var konstruktor = function (divElement, brojZadataka) {

        var text="<table id='tabela'>";
        text+="<tr>";
        text+="<th>Zadaci</th>";
        text+="<th>Commiti</th>";
        text+="</tr>";

        for (var i = 1; i <= brojZadataka; i++) {
            text+="<tr>";
            text +="<td class='prvaKolona'><a href='https://docs.google.com/document/d/1ZjkBwWG_gsRokjp7oGwDpFm40qXM1tB9AwcV5_Qv8W8/edit'>Zadatak " + i + "</a></td>";
            text+="<td class='praznaKolona'></td>";
            text+="</tr>";
        }
        text += "</table>";
        divElement.insertAdjacentHTML('afterbegin', text);
return{
    dodajCommit: function (ukojireddodajes, url) {

        var tbl = document.getElementById('tabela');

        //broj kolona reda u koji dodajes
        var brojkolona = tbl.rows[ukojireddodajes].cells.length;
        //koji red ima najvise kolona
        var maxbrojkolona = 0;
        for (var i = 0; i < tbl.rows.length; i++) {
            if (tbl.rows[i].cells.length > maxbrojkolona) maxbrojkolona = tbl.rows[i].cells.length;
        }


        //slucaj ako je kolona u koju dodajes prazna kolona
        if ((tbl.rows[ukojireddodajes].cells[brojkolona - 1].getAttribute('class') == 'praznaKolona' && maxbrojkolona == 2) || (tbl.rows[ukojireddodajes].cells[brojkolona - 1].getAttribute('class') == 'praznaKolona' && maxbrojkolona == brojkolona)) {
            createCell(tbl.rows[ukojireddodajes].cells[brojkolona - 1], brojkolona - 1,url);
            var span = tbl.rows[ukojireddodajes].cells[brojkolona - 1].getAttribute('colspan');
            //tbl.rows[ukojireddodajes].cells[brojkolona - 1].setAttribute('colspan', 1);
        }
        else if (tbl.rows[ukojireddodajes].cells[brojkolona - 1].getAttribute('class') == 'praznaKolona' && maxbrojkolona != brojkolona) {
            createCell(tbl.rows[ukojireddodajes].cells[brojkolona - 1], brojkolona - 1,url);
            var span = tbl.rows[ukojireddodajes].cells[brojkolona - 1].getAttribute('colspan');
            tbl.rows[ukojireddodajes].cells[brojkolona - 1].setAttribute('colspan', 1);
            //dodas novu celiju
            tbl.rows[ukojireddodajes].insertCell(brojkolona);
            //stavaljas joj atribut klase na praznu kolonu
            tbl.rows[ukojireddodajes].cells[brojkolona].setAttribute('class', 'praznaKolona');
            //span joj smanjujes za 1 u onnosu na celiju koja je prije bila posljednja
            tbl.rows[ukojireddodajes].cells[brojkolona].setAttribute('colspan', span - 2);
        }
        else if (maxbrojkolona == brojkolona && tbl.rows[ukojireddodajes].cells[brojkolona - 1].getAttribute('class') != 'praznaKolona') {
            createCell(tbl.rows[ukojireddodajes].insertCell(maxbrojkolona), tbl.rows[ukojireddodajes].cells.length - 1,url);
            brojkolona = tbl.rows[ukojireddodajes].cells.length;
            tbl.rows[ukojireddodajes].cells[brojkolona - 2].setAttribute('colspan', 1);
            for (var j = 0; j < tbl.rows.length; j++) {
                if (j != ukojireddodajes) {
                    var brojkolonatogreda = tbl.rows[j].cells.length;
                    if (brojkolonatogreda == maxbrojkolona && maxbrojkolona != 2 && tbl.rows[j].cells[brojkolonatogreda - 1].getAttribute('class') == 'broj') {
                        tbl.rows[j].insertCell(brojkolonatogreda);
                        tbl.rows[j].cells[brojkolona - 1].setAttribute('class', 'praznaKolona');
                    }
                    else {
                        var span = tbl.rows[j].cells[brojkolonatogreda - 1].getAttribute("colspan");
                        if (span == null) span = 1;
                        tbl.rows[j].cells[brojkolonatogreda - 1].setAttribute("colspan", span + 1);
                    }
                }
            }
        }
    },
editujCommit:function(rbZadatka,rbCommita,url){},
obrisiCommit:function(rbZadatka,rbCommita){}
}
}
return konstruktor;
});


function createCell(cell, text, url) {
    var a = document.createElement('a');
    a.setAttribute("href", url);
    a.innerHTML = text;
    cell.setAttribute('class', "broj");
    cell.appendChild(a);
}