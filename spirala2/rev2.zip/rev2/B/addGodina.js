var validacija = Validacija(document.getElementById('zagreske'));
var x ;
var AddGodina = function () {
    var mojregex = /[A-Za-z0-9\-\;\'\:]+/;
    x = validacija(document.getElementById('zagreske'));

    //provjera za naziv
    if (x.godina(document.getElementById('naziv').value)) {
        document.getElementById('naziv').style.backgroundColor = "white";
	} else {
        document.getElementById('naziv').style.backgroundColor = "orangered";
    }

    //provjera za repozitorij spirala
    if (x.repozitorij(document.getElementById('rspiral').value, mojregex)) {
        document.getElementById('rspiral').style.backgroundColor = "white";
    } else {
        document.getElementById('rspiral').style.backgroundColor = "orangered";
    }


	//provjera za repozitorij vjvezbi
    if (x.repozitorij(document.getElementById('rvjezbe').value, mojregex)) {
        document.getElementById('rvjezbe').style.backgroundColor = "white";
	} else {
        document.getElementById('rvjezbe').style.backgroundColor = "orangered";
    }

    return false;

  
}