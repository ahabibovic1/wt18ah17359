var v = Validacija(document.getElementById('zagreske'));
var x;

var Zadaci = function () {
    x = v(document.getElementById('zagreske'));
    if (x.ime(document.getElementById('input').value)) {
        document.getElementById('input').style.backgroundColor = "white";
	} else {
        document.getElementById('input').style.backgroundColor = "orangered";
    }

    return false;
}