var div=document.getElementById('divZaTabelu');
var f = CommitTabela(div, 1);
var trenutnoredova=0;
var x;

var kreiraj = function () {
    var tabela = document.getElementById('tabela');
    var kolikoZadataka = document.getElementById('brZad').value;
    if (tabela == null) {
        if (kolikoZadataka != null) {
            x = f(document.getElementById('divZaTabelu'), parseInt(kolikoZadataka));
            trenutnoredova = parseInt(kolikoZadataka);

        }
    }
    else if (kolikoZadataka!=null && trenutnoredova != parseInt(kolikoZadataka)) {
        document.getElementById('divZaTabelu').removeChild(document.getElementById('tabela'));
        f = CommitTabela(document.getElementById('divZaTabelu'), parseInt(kolikoZadataka));
        x = f(document.getElementById('divZaTabelu'), parseInt(kolikoZadataka));
        trenutnoredova = parseInt(kolikoZadataka);
    }

    return false;
}

var dodaj = function () {
    var uToIduGreske = document.getElementById('zagreske');
    var uKojiRed = document.getElementById('brojZadatka');

    var v = Validacija(uToIduGreske);
    var y = v(uToIduGreske);

    if (y.url(document.getElementById('url').value)) {
        document.getElementById('url').style.backgroundColor = "white";
        if (uKojiRed.value != "" && document.getElementById('url').value != "") {
            x.dodajCommit(uKojiRed.value, document.getElementById('url').value);
        }

    }
    else {
        document.getElementById('url').backgroundColor = "orangered";
    }
    return false;
    
}


var obrisi = function () {

}
/*
var edituj = function () {
    var textGreske = document.getElementById('greske');
    var input = document.getElementById('url');
    var validacija = Validacija(textGreske);
    var f = validacija(textGreske);
    if (!f.url(input.value)) {
        input.style.backgroundColor = "orangered";
    } else {
        input.style.backgroundColor = "white";
    }

}*/