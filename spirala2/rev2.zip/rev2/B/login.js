var v = Validacija(document.getElementById('zagreske'));
var x ;

var Login = function () {

    x = v(document.getElementById('zagreske'));

    if (x.password(document.getElementById('password').value)) {
        document.getElementById('password').style.backgroundColor = "white";
    } else {
        document.getElementById('password').style.backgroundColor = "orangered";
    }

    if (x.naziv(document.getElementById('username').value)) {
        document.getElementById('username').style.backgroundColor = "white";
	} else {
        document.getElementById('username').style.backgroundColor = "orangered";
	}
	
    return false;
}