function Foo(){
    var side = document.getElementById("side");
    var inputi = document.getElementsByTagName("input")
    var validator = new Validacija(side);

    validator.godina(inputi[0]);
    validator.naziv(inputi[1]);
    validator.naziv(inputi[2]);
}