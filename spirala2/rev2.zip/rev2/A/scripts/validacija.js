var Validacija=(function(){
    var o = 0;
    let upozorenjeDiv = document.createElement("div");
    let upozorenje = document.createElement("p");
    let validnaPolja = [true,true,true,true,true,true,true];
    let poruka="";
    var x;
    const imeRegex = /^[A-Z]'?([A-Za-z]'?)+([ |-][A-Z]'?([A-Za-z]'?)+){0,3}$/
    const godinaRegex = /^20\d{2}\/20\d{2}$/
    const indexRegex = /^((1[4-9])|20)\d{3}$/
    const nazivRegex = /^[A-Za-z][A-Za-z0-9-‘“!?:;,\\\/]+([a-z0-9])$/
    const passwordRegex = /^[A-Za-z0-9]{8,}$/
    const pwRegex1 = /[A-Z]/
    const pwRegex2 = /[a-z]/
    const pwRegex3 = /[0-9]/
    //                 Mogući protokoli,obavezno ://, obavezno host    za dodavanje sa ., putanja                                            , parametri
    const urlRegex = /^(http|https|ftp|ssh):\/\/([0-9a-z]+(-[0-9a-z]+)*)(.[0-9a-z]+)*\/?(([0-9a-z]+(-[0-9a-z]+)*)\/?)?(\?[0-9a-z]+(-[0-9a-z]+)*=[0-9a-z]+(-[0-9a-z]+)*&[0-9a-z]+(-[0-9a-z]+)*=[0-9a-z]+(-[0-9a-z]+)*)?$/
    
    

    var Validacija = function(divElementPoruke){
        if (o == 0){
            upozorenjeDiv.appendChild(upozorenje)
            upozorenjeDiv.style.textAlign = "center";
            divElementPoruke.appendChild(upozorenjeDiv)
            o++
        }

        const IspisiUpozorenje = (function() {
            poruka = "Sljedeća polja nisu validna: ";
            if (!validnaPolja[0])
                poruka +="ime,"
            if (!validnaPolja[1])
                poruka +="godina,"    
            if (!validnaPolja[2])
                poruka +="repozitorij,"
            if (!validnaPolja[3])
                poruka +="index,"
            if (!validnaPolja[4])
                poruka +="naziv,"
            if (!validnaPolja[5])
                poruka +="password,"
            if (!validnaPolja[6])
                poruka +="url,"

            if (poruka.length > 29){ //Ako je nesto zapravo dodano
                poruka = poruka.substr(0, poruka.length-1) + "!"
                x = upozorenjeDiv.getElementsByTagName("p");
                x[x.length-1].innerHTML=poruka;
            }
            else{
                x = divElementPoruke.getElementsByTagName("p");
                x[x.length-1].innerHTML=""
            }
        })


        return{
            ime:function(inputElement){     
                if (!imeRegex.test(inputElement.value)){
                    validnaPolja[0] = false;
                    inputElement.style.backgroundColor = "orangered";
                }
                else if (inputElement.style.backgroundColor === "orangered") {//Ako je ok vrati na bijelo
                    validnaPolja[0] = true;
                    inputElement.style.backgroundColor = "white";
                }
                IspisiUpozorenje();
            },
            godina:function(inputElement){
                if (godinaRegex.test(inputElement.value)){
                    const testedText = inputElement.value;
                    if ((parseInt(testedText[2])*10+parseInt(testedText[3]) + 1) ===  (parseInt(testedText[7])*10+parseInt(testedText[8]))){
                        if (inputElement.style.backgroundColor === "orangered"){
                            inputElement.style.backgroundColor = "white";
                            validnaPolja[1] = true;
                        }
                        IspisiUpozorenje();
                        return;
                    }
                }
                validnaPolja[1] = false;
                inputElement.style.backgroundColor = "orangered";
                IspisiUpozorenje();
            },
            repozitorij:function(inputElement, regex){
                if (!regex.test(inputElement.value)){
                    validnaPolja[2] = false;
                    inputElement.style.backgroundColor = "orangered";
                }
                else if (inputElement.style.backgroundColor === "orangered") {//Ako je ok vrati na bijelo
                    validnaPolja[2] = true;
                    inputElement.style.backgroundColor = "white";
                }
                IspisiUpozorenje();
            },
            index:function(inputElement){
                if (!indexRegex.test(inputElement.value)){
                    validnaPolja[3] = false;
                    inputElement.style.backgroundColor = "orangered";
                }
                else if (inputElement.style.backgroundColor === "orangered") {//Ako je ok vrati na bijelo
                    validnaPolja[3] = true;
                    inputElement.style.backgroundColor = "white";
                }
                IspisiUpozorenje();
            },
            naziv:function(inputElement){
                if (!nazivRegex.test(inputElement.value)){
                    validnaPolja[4] = false;
                    inputElement.style.backgroundColor = "orangered";
                }
                else if (inputElement.style.backgroundColor === "orangered") {//Ako je ok vrati na bijelo
                    validnaPolja[4] = true;
                    inputElement.style.backgroundColor = "white";
                }
                IspisiUpozorenje();
            },
            password:function(inputElement){
                if (passwordRegex.test(inputElement.value) && (pwRegex1.test(inputElement.value)&&pwRegex2.test(inputElement.value) 
                || pwRegex1.test(inputElement.value)&&pwRegex3.test(inputElement.value) || pwRegex2.test(inputElement.value)&&pwRegex3.test(inputElement.value))){
                    if (inputElement.style.backgroundColor === "orangered") {//Ako je ok vrati na bijelo
                        validnaPolja[5] = true;
                        inputElement.style.backgroundColor = "white";
                    }
                }
                else{
                    validnaPolja[5] = false;
                    inputElement.style.backgroundColor = "orangered";
                }
                IspisiUpozorenje();
            },
            url:function(inputElement){
                if (!urlRegex.test(inputElement.value)){
                    validnaPolja[6] = false;
                    inputElement.style.backgroundColor = "orangered";
                }
                else if (inputElement.style.backgroundColor === "orangered") {//Ako je ok vrati na bijelo
                    validnaPolja[6] = true;
                    inputElement.style.backgroundColor = "white";
                }
                IspisiUpozorenje();
                return false;
            }
        }
    }
    return Validacija;
}())
