function Foo(){
    var glavni = document.getElementsByClassName("cetvrtina");
    var input = document.getElementsByTagName("input")
    
    var validator = new Validacija(glavni[1]);

    validator.index(input[0])
}