function Foo(){
    var glavni = document.getElementById("glavniSadrzaj");
    var inputi = document.getElementsByTagName("input")
    var validator = new Validacija(glavni);

    validator.naziv(inputi[0]);
}