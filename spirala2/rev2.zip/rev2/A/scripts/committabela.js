var CommitTabela = (function(){
    let i; let table; let row; let cell; let a; let maks; let j;

    //Pravi tabelu
    var CommitTabela = function(divElement, brojZadataka){
        table = document.createElement("TABLE");
        table.style.borderCollapse = "collapse";
        table.style.border = "1px solid black"

        row = table.insertRow(0);
        cell = row.insertCell(0);
        cell.innerHTML = "Zadaci";
        cell.style.border = "1px solid black"
        cell = row.insertCell(1);
        cell.innerHTML="Commiti";
        cell.style.border = "1px solid black"

        for (i=1; i <= brojZadataka; i++){
            row = table.insertRow(i);
            cell = row.insertCell(0)
            cell.style.border = "1px solid black"
            cell.innerHTML = "Zadatak " + i.toString();
            cell = row.insertCell(1);
            cell.style.border = "1px solid black"
            cell.innerHTML="";
        }
        divElement.appendChild(table)

        return {
            dodajCommit:function(rbZadatka, url){
                //Logika ove funkcije konstruirana je tako da indeksira od 1, jer se drugi red indeksira sa 0 slijedi:
                rbZadatka+=1;

                //Kreiraj link
                a = document.createElement("a");
                a.href = url;

                //Provjeri koja je maksimalni broj item-a u redu
                maks = table.rows[0].cells.length;
                for (i = 1; i< brojZadataka; i++)
                    if (maks < table.rows[i].cells.length)
                        maks = table.rows[i].cells.length;
                
                // Ako je trazeno mjesto prazno
                if (table.rows[rbZadatka].lastChild.innerHTML === ""){
                    cell = table.rows[rbZadatka].lastChild;
                    
                    if (table.rows[rbZadatka].cells.length <= 2) //Ako je prvi
                        a.innerHTML = 1;
                    else{
                        var x = cell.previousSibling.getElementsByTagName('a');
                        a.innerHTML = parseInt(x[0].innerHTML) +1;
                    }
                    cell.appendChild(a);
                    cell.colSpan = 1;
                    
                    //Ako ima jos mjesta do kraja
                    if (table.rows[rbZadatka].cells.length < maks){
                        cell = table.rows[rbZadatka].insertCell(-1); //Dodaj celiju
                        cell.style.border = "1px solid black"
                        cell.colSpan = maks - table.rows[rbZadatka].childElementCount +1; //Prosiri do kraja
                    }
                }
                else{
                    if (table.rows[rbZadatka].cells.length < maks){ //Ako ima mjesta za dodati
                        cell = table.rows[rbZadatka].insertCell(-1);
                        if (table.rows[rbZadatka].cells.length <= 2) //Ako je prvi
                            a.innerHTML = 1;
                        else{
                            var x = cell.previousSibling.getElementsByTagName('a');
                            a.innerHTML = parseInt(x[0].innerHTML) +1;
                        }
                        cell.appendChild(a);
                        

                        if (table.rows[rbZadatka].cells.length < maks){ //If there is still space
                            cell = table.rows[rbZadatka].insertCell(-1); //Add a cell
                            cell.style.border = "1px solid black"
                            cell.colSpan = maks - table.rows[rbZadatka].childElementCount; //Expand it until the end
                        }
                    }
                    else{ //No more place in the table
                        for (i = 0; i < table.rows.length; i++){
                            if (i == rbZadatka){ //Dodaj polje
                                cell = table.rows[i].insertCell(-1);
                                cell.style.border = "1px solid black"
                                if (table.rows[rbZadatka].cells.length <= 2) //Ako je prvi
                                    a.innerHTML = 1;
                                else{
                                    var x = cell.previousSibling.getElementsByTagName('a');
                                    a.innerHTML = parseInt(x[0].innerHTML) +1;
                                }
                                cell.appendChild(a);
                            }
                            else{ //Produzi colspan zadnjeg
                                if (table.rows[i].lastChild.innerHTML === "" || table.rows[i].lastChild.innerHTML === "Commiti")
                                    table.rows[i].lastChild.colSpan = table.rows[i].lastChild.colSpan + 1;
                                else{
                                    table.rows[i].insertCell(-1); //Add a cell
                                    cell.style.border = "1px solid black"
                                }
                            }
                        }
                    }
                }
            },
            editujCommit:function(rbZadatka, rbCommita,url){
                //Uradjeno da pocne od 1, ne od nule. Pa zato je ova kompenzacija
                rbZadatka+=1; 
                rbCommita+=1;
                
                
                if (rbZadatka > table.rows.length || rbZadatka <= 0 || 
                    rbCommita > table.rows[rbZadatka].cells.length || rbCommita <= 0 || 
                    table.rows[rbZadatka].cells[rbCommita].childElementCount === 0)
                    return -1;
                    
                table.rows[rbZadatka].cells[rbCommita].lastChild.href = url; 
            },
            obrisiCommit:function(rbZadatka, rbCommita){
                //Uradjeno da pocne od 1, ne od nule. Pa zato je ova kompenzacija
                rbZadatka+=1; 
                rbCommita+=1;
                
                //Testiranje da li su ok parametri, predpostavka - pocinjemo od 1, ako ne smanji za jedan i promjeni uslove na < 0
                if (rbZadatka >= table.rows.length || rbZadatka <= 0 || 
                    rbCommita >= table.rows[rbZadatka].cells.length || rbCommita <= 0 ||
                    table.rows[rbZadatka].cells[rbCommita].innerHTML==="")
                    return -1;
                
                //Da li je izabrani element jedini u koloni
                for (i = 1; i<= brojZadataka; i++)
                    if (i != rbZadatka && table.rows[rbZadatka].cells.length <= table.rows[i].cells.length && table.rows[i].lastChild.innerHTML !== "")
                        break;

                if (i === brojZadataka+1){ // Jedini je
                    for (i = 0; i< brojZadataka; i++){
                        if (i === rbZadatka)
                            table.rows[rbZadatka].cells[rbCommita].remove();
                        
                        else{
                            if (table.rows[i].lastChild.colSpan > 1)
                                table.rows[i].lastChild.colSpan -= 1;
                            else
                                table.rows[i].lastChild.remove(); 
                        }
                    }
                }
                else{ //Nije jedini
                    table.rows[rbZadatka].cells[rbCommita].remove();
                    if (table.rows[rbZadatka].lastChild.innerHTML === "")
                        table.rows[rbZadatka].lastChild.colSpan +=1;
                    else
                        table.rows[rbZadatka].insertCell().innerHTML="";
                }
            }
        }
    }

    return CommitTabela;
}());