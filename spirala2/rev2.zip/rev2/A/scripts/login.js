function Foo(){
    var glavni = document.getElementById("login");
    var input = document.getElementsByTagName("input")
    
    var validator = new Validacija(glavni);

    validator.ime(input[0])
    validator.password(input[1])
}