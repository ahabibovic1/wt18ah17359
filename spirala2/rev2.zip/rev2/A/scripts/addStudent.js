function Foo(){
    var glavni = document.getElementById("glavniSadrzaj");
    var inputi = document.getElementsByTagName("input")
    var validator = new Validacija(glavni);

    validator.ime(inputi[0]);
    validator.index(inputi[1])
}