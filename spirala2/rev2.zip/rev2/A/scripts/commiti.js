var tabela;

function KreirajTabelu(){
    var mojDiv=document.getElementById("glavniSadrzaj");
    var input=document.getElementById("brojZadataka");

    tabela = new CommitTabela(mojDiv, input.value);
}

function DodajCommit(){
    var rbZadatka = parseInt(document.getElementById('rbZadatkaDodaj').value);
    var commit = document.getElementById('urlDodaj');
    var glavni = document.getElementById("glavniSadrzaj")
    var validator = new Validacija(glavni)
    validator.url(commit)

    tabela.dodajCommit(rbZadatka, commit.value)
}

function UrediCommit(){
    var rbZadatka = parseInt(document.getElementById('rbZadatkaUredi').value);
    var rbCommita = parseInt(document.getElementById('rbCommitaUredi').value);
    var commit = document.getElementById('urlUredi');
    var glavni = document.getElementById("glavniSadrzaj")
    var validator = new Validacija(glavni)
    if (!validator.url(commit)) return;
    
    if (tabela.editujCommit(rbZadatka, rbCommita, commit.value) === -1)
        alert("Neispravni ulazni podaci!")
}

function ObrisiCommit(){
    var rbZadatka = parseInt(document.getElementById('rbZadatkaObrisi').value);
    var rbCommita = parseInt(document.getElementById('rbCommitaObrisi').value);
    
    if (tabela.obrisiCommit(rbZadatka, rbCommita))
        alert("Neispravni ulazni podaci!")
}